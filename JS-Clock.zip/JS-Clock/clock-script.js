function digitalClock() {
    var today=new Date();
    var s=today.getSeconds();
    var m=today.getMinutes();
    var h=today.getHours();
    var d=today.getDate();
    var month=today.getMonth();
    var year=today.getFullYear();

    var hours=h;
    var monthName=["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December" ];

    var greetings, value;
    var am="AM";
    var pm="PM";

    //Greeting
    if( h >= 0 && h <=12 ){
        greetings="Good Morning";
    }
    else if (h > 12 && h < 16){
        greetings="Good Afternoon";
    }else if (h >= 16 && h < 21){
        greetings="Good Evening";
    }else{
        greetings="Good Night";
    }

    //-----------12hrs format---------
    if(hours == 0){
        hours=12;
    }

    if( hours > 12){
        hours=hours - 12;
    }

    //------adding AM and PM---------
    if(h >= 0 && h < 12){

        value=am;
    }
    else if(h >= 12 && h <= 24){
        value=pm;
    }


    m = checkTime(m);
    s = checkTime(s);

    document.getElementById("greeting-msg").innerHTML=
        greetings;
    document.getElementById("current-time").innerHTML=
        hours + " : " + m + " : " + s + "  " + value ;
    document.getElementById("current-date").innerHTML=
        d + " " + monthName[month] + " " + year;

    var timeout=setTimeout(digitalClock, 1000);
}

//--------add zero in front of numbers < 10
function checkTime(time_value) {
    if (time_value < 10)
    {
        time_value = "0" + time_value;
    };
    return time_value;
}